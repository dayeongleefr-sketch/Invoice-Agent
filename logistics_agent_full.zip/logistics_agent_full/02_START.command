#!/bin/bash
set -eu
cd -- "$(dirname -- "$0")"
export PYTHONUTF8=1
export PATH="/opt/homebrew/bin:/opt/local/bin:/usr/local/bin:$HOME/.local/bin:$PATH"
if [ "$(uname -s)" != Darwin ]; then
  echo "This launcher is for macOS. On Windows use the .cmd files." >&2
  exit 1
fi
trap 'echo "Stopped. Read the error above; your saved data was kept." >&2' ERR
if [ ! -x .venv/bin/python ]; then
  echo "Run 01_SETUP.command first." >&2; exit 1
fi
exec .venv/bin/python -X utf8 portable.py serve "$@"
