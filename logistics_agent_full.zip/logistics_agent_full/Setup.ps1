$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($PSScriptRoot)
Set-Location -LiteralPath $root
$env:PYTHONUTF8='1'
$runtime=Join-Path $root 'ia/.runtime/python'
$bootstrap=Join-Path $root '.bootstrap'
$python=Join-Path $runtime 'python.exe'
if(-not [Environment]::Is64BitOperatingSystem){throw 'Windows x64 is required.'}
New-Item -ItemType Directory -Path $runtime,$bootstrap -Force | Out-Null
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
if(-not (Test-Path -LiteralPath $python)){
    $archive=Join-Path $bootstrap 'python-3.12.10-embed-amd64.zip'
    Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip' -OutFile $archive
    if((Get-FileHash -LiteralPath $archive -Algorithm MD5).Hash -ne 'FE8EF205F2E9C3BA44D0CF9954E1ABD3'){throw 'Python distribution checksum mismatch.'}
    Expand-Archive -LiteralPath $archive -DestinationPath $runtime -Force
}
[IO.File]::WriteAllText((Join-Path $runtime 'python312._pth'),"python312.zip`n.`nLib`nLib/site-packages`nimport site`n",[Text.UTF8Encoding]::new($false))
if(-not (Test-Path -LiteralPath (Join-Path $runtime 'Lib/site-packages/pip'))){
    $pip=Join-Path $bootstrap 'get-pip.py'
    Invoke-WebRequest -UseBasicParsing 'https://bootstrap.pypa.io/get-pip.py' -OutFile $pip
    & $python $pip --disable-pip-version-check
    if($LASTEXITCODE -ne 0){throw 'pip setup failed. Check internet/proxy settings.'}
}
& $python -m pip install --disable-pip-version-check -r (Join-Path $root 'requirements.txt')
if($LASTEXITCODE -ne 0){throw 'Dependency installation failed. Existing data was kept.'}
& $python -X utf8 (Join-Path $root 'portable.py') init
if($LASTEXITCODE -ne 0){throw 'Initial calculation failed. See the error above.'}
Write-Host 'Setup complete. Run 02_START.cmd. AI login is separate; see README.'
