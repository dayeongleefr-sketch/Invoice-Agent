@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Backup.ps1"
if errorlevel 1 echo Failed. Please read the error above.
pause
