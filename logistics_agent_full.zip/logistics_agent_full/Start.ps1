param([int]$Port=8090,[switch]$NoBrowser)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
$python=Join-Path $PSScriptRoot 'ia/.runtime/python/python.exe'
if(-not (Test-Path -LiteralPath $python)){throw 'Run 01_SETUP.cmd first.'}
$arguments=@('-X','utf8',(Join-Path $PSScriptRoot 'portable.py'),'serve','--port',[string]$Port)
if($NoBrowser){$arguments+='--no-browser'}
& $python @arguments
exit $LASTEXITCODE
