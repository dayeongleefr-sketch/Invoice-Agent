$ErrorActionPreference='Stop'
$codex=Get-Command codex.exe -ErrorAction SilentlyContinue
if(-not $codex){
    Write-Host 'Install Codex CLI for Windows and make codex.exe available on PATH:'
    Write-Host 'https://learn.chatgpt.com/docs/cli'
    throw 'Codex CLI was not found. Installation guidance is in README.'
}
& $codex.Source login
if($LASTEXITCODE -ne 0){throw 'AI sign-in did not complete.'}
Write-Host 'AI sign-in complete. Credentials stay in this PC account, outside the application ZIP.'
