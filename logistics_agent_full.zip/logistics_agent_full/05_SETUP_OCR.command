#!/bin/bash
set -eu
cd -- "$(dirname -- "$0")"
export PYTHONUTF8=1
export PATH="/opt/homebrew/bin:/opt/local/bin:/usr/local/bin:$HOME/.local/bin:$PATH"
if [ "$(uname -s)" != Darwin ]; then
  echo "This launcher is for macOS. On Windows use the .cmd files." >&2
  exit 1
fi
trap 'echo "Stopped. Read the error above; your saved data was kept." >&2' ERR
if [ ! -x .venv/bin/python ]; then
  echo "Run 01_SETUP.command first." >&2; exit 1
fi
if .venv/bin/python -X utf8 ia/src/portable_ocr.py; then
  echo "Local Korean/English OCR is ready."; exit 0
fi
if ! command -v brew >/dev/null 2>&1; then
  echo "Install Homebrew from https://brew.sh, then run this file again."
  echo "Alternatively install Tesseract with Korean and English data via MacPorts."
  /usr/bin/open 'https://brew.sh' || true
  exit 1
fi
brew install tesseract tesseract-lang
.venv/bin/python -X utf8 ia/src/portable_ocr.py
echo "Local Korean/English OCR is ready. OCR values still require source review."
