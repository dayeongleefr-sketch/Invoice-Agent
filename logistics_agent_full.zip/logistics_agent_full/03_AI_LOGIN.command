#!/bin/bash
set -eu
cd -- "$(dirname -- "$0")"
export PYTHONUTF8=1
export PATH="/opt/homebrew/bin:/opt/local/bin:/usr/local/bin:$HOME/.local/bin:$PATH"
if [ "$(uname -s)" != Darwin ]; then
  echo "This launcher is for macOS. On Windows use the .cmd files." >&2
  exit 1
fi
trap 'echo "Stopped. Read the error above; your saved data was kept." >&2' ERR
if ! command -v codex >/dev/null 2>&1; then
  echo "Install Codex CLI for macOS, then open a new Terminal and retry."
  echo "https://learn.chatgpt.com/docs/cli"
  /usr/bin/open 'https://learn.chatgpt.com/docs/cli' || true
  exit 1
fi
codex login
echo "AI sign-in complete. Credentials stay outside this app and its backups."
