# Mac에서 설치·실행하기

대상: macOS 13 이상, Apple Silicon(M 시리즈) 또는 Intel. 두 종류를 위한 실행 스크립트를 포함합니다.
**실제 Mac 장비의 설치·브라우저·AI·복구 인수는 아직 수행하지 않았습니다.** Windows에서의 시험과 구분합니다.

1. Drive의 최신 `logistics_agent_full.zip`을 내려받아 로컬 폴더에 완전히 압축 해제합니다.
   Drive 동기화 폴더에서 여러 PC가 같은 DB를 동시에 실행하지 않습니다.
2. [공식 Python 3.12.10 페이지](https://www.python.org/downloads/release/python-31210/)의
   **macOS 64-bit universal2 installer**를 설치합니다. 기존 Windows 시험 버전과 맞춘 기준이며 최신 Python이라는 뜻은 아닙니다.
   Python 3.12 계열을 사용하며, 최신 계열 3.13 이상을 대신 설치하지 않습니다.
   [공식 Mac 안내](https://docs.python.org/3.12/using/mac.html)의 universal2 배포는 Apple Silicon과 Intel을 지원합니다.
   설치 후 `/Applications/Python 3.12/Install Certificates.command`도 실행합니다.
3. **01_SETUP.command**를 실행합니다. 앱 전용 `.venv`에 라이브러리를 설치하고 가상 청구·WMS를 실제 계산합니다.
   Python이 없으면 공식 설치 페이지를 열고 중단하므로 설치 후 다시 실행합니다. 관리자 권한으로 앱 스크립트를 실행할 필요는 없습니다.
4. **02_START.command**를 실행합니다. `http://127.0.0.1:8090`에서 웹 화면이 열립니다.
   터미널은 열어 두고, 종료하려면 해당 터미널에서 Control+C를 누릅니다.
5. 실제 AI를 쓰려면 [공식 Codex CLI](https://learn.chatgpt.com/docs/cli)를 Mac에 설치하고
   **03_AI_LOGIN.command**에서 본인 계정으로 로그인합니다. 새 터미널의 `command -v codex`로 설치 여부를 확인할 수 있습니다.
   Python 계산·저장 결과 조회와 AI 로그인을 구분합니다. 실패한 AI 호출을 모의 성공으로 바꾸지 않습니다.
6. 앱을 종료한 뒤 **04_BACKUP.command**를 실행하고 `backups/`의 새 ZIP을 Drive에 올립니다.
   Windows와 Mac 모두 최신 백업을 새 폴더에 압축 해제하고 각 OS의 01→02→03 순서로 다시 설치합니다.
   소스·입력·결과·처리 이력·대화가 보관되고 실행환경은 해당 OS에 다시 설치합니다. 인증은 PC마다 다시 합니다.

## 더블클릭이 안 될 때

터미널에서 `cd `를 입력한 다음 압축을 푼 `logistics_agent_full` 폴더를 끌어 놓고 Enter를 누릅니다.
아래에서 필요한 명령 하나를 실행합니다. 실행 권한이 빠진 ZIP을 푼 경우에도 `bash`로 실행할 수 있습니다.

```bash
bash 01_SETUP.command
bash 02_START.command
bash 03_AI_LOGIN.command
bash 04_BACKUP.command
```

첫 실행이 macOS 보안 설정으로 차단되면 파일 출처를 확인하고 시스템 설정의 개인정보 보호 및 보안에서 허용합니다.
보안 기능 전체를 끄는 명령은 필요하지 않습니다. 네 명령을 한 번에 실행하지 말고, 백업 전에 앱을 종료하세요.
8090 포트를 사용 중이면 `bash 02_START.command --port 8091`로 엽니다.
인증서 오류는 위 Install Certificates.command와 회사 네트워크 정책을 확인합니다. TLS 검증을 끄지 않습니다.
환경 설치 실패는 성공으로 표시하지 않습니다. 오류와 Mac의 OS 버전·칩 종류를 함께 확인해야 합니다.

## 지원 범위와 복구 시 주의점

- 대시보드·확인 목록·상세·텍스트 PDF·XLSX/CSV 계산·ReAct·채팅·담당자 처리·백업용 Mac 경로를 추가했습니다.
- **스캔 PDF:** `05_SETUP_OCR.command`로 로컬 한국어·영어 OCR을 준비합니다. 아래 OCR 절차를 따릅니다.
- **과거 재현:** 보관된 원본·코드·기준을 격리 복원해 저장 결과 전체와 비교합니다. Windows 보관 자료도 Mac에서 재계산합니다.
  Windows 운영체제 복제와 구분하며, 실행 환경/라이브러리 정보와 재현 방식을 표시합니다. 불일치·변조·필수 버전 차이는 성공 처리하지 않습니다.
- 다른 PC/OS로 옮기면 코드·원본의 확인값을 다시 검사합니다. 기존 결과가 검증을 통과하지 않으면 자동 초기화하거나 결정을 새 자료에 무조건 적용하지 않습니다.
- `.venv`나 Windows Python 폴더를 다른 OS로 복사해 실행하지 않습니다. 최초 배포와 백업은 OS별 새 설치를 전제로 합니다.
- 기존 2026-11-18 Windows 백업에는 Mac 지원 소스가 없습니다. 최신 배포본을 사용하며, 옛 백업을 새 소스 위에 덮어쓰지 않습니다.
- Mac 실기기 인수: 설치 → 가상 결과/원본/보고서 → 실제 AI → 담당자 처리/대화 → 백업 → 다른 폴더 복구를 확인합니다.
  전체 업무 양식·모든 Mac 버전 지원 완료를 의미하지 않습니다.

## 스캔 PDF OCR (추가 기능)

1. `01_SETUP.command`로 PDFium·Pillow를 포함한 앱 라이브러리를 설치합니다.
2. `05_SETUP_OCR.command`를 실행합니다. 이미 한국어·영어 Tesseract가 있으면 확인만 합니다.
   없다면 [Homebrew 공식 설치](https://brew.sh)를 먼저 수행하고 다시 실행합니다.
   스크립트는 `brew install tesseract tesseract-lang`을 수행합니다.
   [공식 Tesseract 설치 안내](https://tesseract-ocr.github.io/tessdoc/Installation.html),
   [Homebrew 언어 자료](https://formulae.brew.sh/formula/tesseract-lang).
   MacPorts 설치도 사용할 수 있으며 `tesseract --list-langs`에 `kor`, `eng`가 있어야 합니다.
   Homebrew가 해당 macOS/Intel 조합을 지원하지 않으면 설치 오류를 해결한 뒤 진행하며 모든 Mac 설치 완료로 간주하지 않습니다.
3. 월별 자료 등록에서 스캔 계약 PDF를 등록합니다. 이미지 페이지는 로컬에서 렌더링·문자 인식합니다.
   페이지·단어 좌표·엔진/언어 자료 버전을 보관하고 문자 인식 금액은 원본 확인 전 확정하지 않습니다.
   텍스트 PDF는 기존 방식으로 읽으며, OCR 실패·빈 결과·암호 PDF·100쪽 초과는 미확인으로 남깁니다.

OCR 파일은 외부 AI에 전송하지 않습니다. 설치 후 인식은 로컬 처리이며 AI 호출 비용이 들지 않습니다.
기존 Windows OCR과 같은 문자/표 해석을 보장하지 않으므로 표의 항목·단위·숫자를 원본과 확인합니다.

## Windows에서 보관한 과거 계산을 Mac에서 재현

- 비교 기준을 명시 적용하면 당시 원본·계산 소스·기준·연쇄 참조·결과를 해시로 묶어 보관합니다.
  새 버전은 Python·계산 라이브러리 버전도 기록하며 Mac에서도 보관합니다. 백업 ZIP에 함께 포함됩니다.
- 기준 이력에서 **보관 자료로 재현 확인**을 선택합니다. 현재 원본·기준·결정은 덮어쓰지 않습니다.
- 같은 Windows 실행환경이 보관되어 있고 Windows에서 실행하면 기존 방식으로 복원합니다.
  Mac에서는 보관 코드·원본을 현재 OS에서 격리 계산하고 전체 저장 결과가 일치하는지 확인합니다.
- 새 묶음은 Python 패치 버전과 계산 라이브러리 버전을 확인합니다. 다르면 중단하므로 보관 버전과 맞는 별도 설치본을 준비합니다.
  이전 Windows 묶음에 환경 버전 정보가 없으면 **이전 백업·환경 버전 미확인**으로 구분하고 결과 일치 여부만 확인합니다.
- OS 자체나 과거 AI 문장까지 복제하는 기능은 아닙니다. 값이 다르거나 근거가 변조된 경우 재현 성공으로 표시하지 않습니다.
- 소스/원장까지 있는 이전 백업이 필요합니다. 당시 자료가 없는 요약 보고서만으로 과거 원본을 만들어내지 않습니다.

실제 Mac에서의 OCR 엔진 실행과 Windows↔Mac 장비 간 재현 인수는 아직 대기입니다.
제공된 Windows 시험·OCR 인터페이스 모의 시험을 실제 Mac 완료로 해석하지 않습니다.
