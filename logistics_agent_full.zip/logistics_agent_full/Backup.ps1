$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
$python=Join-Path $PSScriptRoot 'ia/.runtime/python/python.exe'
if(-not (Test-Path -LiteralPath $python)){throw 'Run 01_SETUP.cmd first.'}
& $python -X utf8 (Join-Path $PSScriptRoot 'portable.py') backup
if($LASTEXITCODE -ne 0){throw 'Backup failed. Close the app and wait for running verification to finish.'}
Write-Host 'Backup created in backups/. Upload that ZIP to your own Drive folder.'
