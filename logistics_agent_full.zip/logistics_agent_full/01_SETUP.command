#!/bin/bash
set -eu
cd -- "$(dirname -- "$0")"
export PYTHONUTF8=1
export PATH="/opt/homebrew/bin:/opt/local/bin:/usr/local/bin:$HOME/.local/bin:$PATH"
if [ "$(uname -s)" != Darwin ]; then
  echo "This launcher is for macOS. On Windows use the .cmd files." >&2
  exit 1
fi
trap 'echo "Stopped. Read the error above; your saved data was kept." >&2' ERR
if [ "$(uname -m)" != arm64 ] && [ "$(uname -m)" != x86_64 ]; then
  echo "Apple Silicon or Intel Mac is required." >&2; exit 1
fi
major=$(/usr/bin/sw_vers -productVersion | /usr/bin/cut -d. -f1)
if [ "$major" -lt 13 ]; then
  echo "This package targets macOS 13 or later." >&2; exit 1
fi
python=""
for candidate in /Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 python3.12; do
  if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys,sqlite3; assert sys.version_info[:2]==(3,12); assert sqlite3.sqlite_version_info>=(3,37,0)' >/dev/null 2>&1; then
    python="$candidate"; break
  fi
done
if [ -z "$python" ]; then
  echo "Install Python 3.12 (macOS universal2) from the official page, then run 01_SETUP.command again."
  echo "https://www.python.org/downloads/release/python-31210/"
  /usr/bin/open 'https://www.python.org/downloads/release/python-31210/' || true
  exit 1
fi
if [ -e .venv ] && [ ! -x .venv/bin/python ]; then
  echo "Incomplete environment. Extract the ZIP into a fresh folder and run setup there." >&2; exit 1
fi
if [ ! -x .venv/bin/python ]; then
  "$python" -m venv --copies .venv
fi
.venv/bin/python -c 'import sys,sqlite3; from pathlib import Path; assert sys.version_info[:2]==(3,12), "Python 3.12 required"; assert Path(sys.prefix).resolve()==(Path.cwd()/".venv").resolve(), "Moved environment: restore the backup ZIP in a fresh folder"; assert sqlite3.sqlite_version_info>=(3,37,0)'
.venv/bin/python -m pip install --disable-pip-version-check --only-binary=:all: -r requirements.txt
.venv/bin/python -X utf8 portable.py init
echo "Setup complete. Run 02_START.command. AI login is separate."
